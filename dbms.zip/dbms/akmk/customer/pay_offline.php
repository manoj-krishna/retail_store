<center><!--  center Begin  -->
    
    <h3> Pay offline easily by just paying the delivery rep</h3>
    <h3> OR  </h3>
     <h3> Paytm to the number given below</h3>
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service work <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->
<hr>
<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
            
                <th> Paytm Details NO1: </th>
                <th> Paytm Details NO2: </th>
                
            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
           
           <td> Number:8217434682 </td>
           <td> Number:9108405601 </td>
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  --